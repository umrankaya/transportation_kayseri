function [sentences_values]=most_freq_line(freq_line_10)
%This function creates membership of hourly day part
sentences_values=[];

stop_card_via_hours=freq_line_10(:,2);    
[maxNum, maxIndex] = max(stop_card_via_hours(:,:)); % MaxNum shows the membership degree
[membership_degree]=fuzzy_c_means(freq_line_10(:,2),3);
membership_degree=sortrows(membership_degree,maxIndex); % this sorts matrix from the first coloumn and keep the rows same
combined=[freq_line_10';membership_degree]; % combine in the same matrix to sort
sorted_combined=sortrows(combined',2); % sorted according to freq.


high_level_line=sorted_combined(size(freq_line_10,1),1);
low_level_line=sorted_combined(1,1);
truth=min(sorted_combined(size(freq_line_10,1),5),sorted_combined(1,3));

sentences_values=[sentences_values;high_level_line];
sentences_values=[sentences_values;low_level_line];
sentences_values=[sentences_values;truth];

end



