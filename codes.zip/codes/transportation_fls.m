clc
clear all

                   %%%%%% importing excel with multiple sheets %%%%%%
                   
                   %%% variables are {id, date, hour, hat, card}%%%
                   
                                    %%% DATA PREPROCESSING %%%%
%%% IMPORTING DATA

[~,sheet_name10]=xlsfinfo('D:\Users\umran.kaya\Desktop\transportation_fls\veri\sample_10.xlsx');
for k=1:numel(sheet_name10)
  data10{k}=xlsread('D:\Users\umran.kaya\Desktop\transportation_fls\veri\sample_10.xlsx',sheet_name10{k})
end

[~,sheet_name17]=xlsfinfo('D:\Users\umran.kaya\Desktop\transportation_fls\veri\sample_17.xlsx');
for j=1:numel(sheet_name17)
  data17{j}=xlsread('D:\Users\umran.kaya\Desktop\transportation_fls\veri\sample_17.xlsx',sheet_name17{j})
end

[~,sheet_name1737]=xlsfinfo('D:\Users\umran.kaya\Desktop\transportation_fls\veri\sample_1737.xlsx');
for l=1:numel(sheet_name1737)
  data1737{l}=xlsread('D:\Users\umran.kaya\Desktop\transportation_fls\veri\sample_1737.xlsx',sheet_name1737{l})
end

[~,sheet_name2771]=xlsfinfo('D:\Users\umran.kaya\Desktop\transportation_fls\veri\sample_2771.xlsx');
for m=1:numel(sheet_name2771)
  data2771{m}=xlsread('D:\Users\umran.kaya\Desktop\transportation_fls\veri\sample_2771.xlsx',sheet_name2771{m})
end


stops={'inonu_bulvari_4_aktarma_duragi','inonu_bulvari_2_aktarma_duragi','osman_kavuncu','harikalar_diyari'}; %%(10,17,1737,2771) nolu duraklar

%% removing duplicate bus line names to use in LS
line_nmber_stop10=0;
line_nmber_stop17=0;
line_nmber_stop1737=0;
line_nmber_stop2771=0;

data10_temp=[];
data17_temp=[];
data1737_temp=[];
data2771_temp=[];
for i=1:14 %aggregating all days for each bus stop to detect dublicated lines and remove them
    temp1=data10(1,i);
    temp1=table2array(temp1);
    data10_temp=[data10_temp;temp1];   
    
    temp2=data17(1,i);
    temp2=table2array(temp2);
    data17_temp=[data17_temp;temp2];
    
    temp3=data1737(1,i);
    temp3=table2array(temp3);
    data1737_temp=[data1737_temp;temp3];
    
    temp4=data2771(1,i);
    temp4=table2array(temp4);
    data2771_temp=[data2771_temp;temp4];
end

% Here, detecting "line" number for each bus stop

data10_temp=data10_temp(:,4); % just selecting "line" coloumn
line_nmber_stop10=unique(data10_temp(:,1)); % unique()is removing dublicated cells
tt=size(line_nmber_stop10);
line_nmber_stop10=tt(1,1);

data17_temp=data17_temp(:,4); % just selecting "line" coloumn
line_nmber_stop17=unique(data17_temp(:,1)); % unique()is removing dublicated cells
tt=size(line_nmber_stop17);
line_nmber_stop17=tt(1,1);

data1737_temp=data1737_temp(:,4); % just selecting "line" coloumn
line_nmber_stop1737=unique(data1737_temp(:,1)); % unique()is removing dublicated cells
tt=size(line_nmber_stop1737);
line_nmber_stop1737=tt(1,1);

data2771_temp=data2771_temp(:,4); % just selecting "line" coloumn
line_nmber_stop2771=unique(data2771_temp(:,1)); % unique()is removing dublicated cells
tt=size(line_nmber_stop2771);
line_nmber_stop2771=tt(1,1);

line_nmber_stop=[line_nmber_stop10,line_nmber_stop17,line_nmber_stop1737,line_nmber_stop2771];


%% Detecting Membership of Density of Bus-stop

stop_density=[size(data10_temp,1); size(data17_temp,1); size(data2771_temp,1);size(data1737_temp,1)]; %% whole density during 2 weeks
[mmbrship_dgre_stop_density]=fuzzy_c_means(stop_density,3);
mmbrship_dgre_stop_density=sortrows(mmbrship_dgre_stop_density); % this sorts matrix from the first coloumn and keep the rows same

                           %%%%%%%%%%%%%%%%%% LINGUISTIC SUMMARIZATION %%%%%%%%%%%%%%%%%%%%%                  
 

%% 1. SENTENCE: 

%%%       "In�n� Boulevard is a stop where "7" lines pass and the density rate is "HIGH". "

s1_labels = {'low','normal','high'}; % Density labels which membership calculated with fuzzy c-means clustering

sentence_1=[];
for i=1:size(stops,2)

    [maxNum, maxIndex] = max(mmbrship_dgre_stop_density(:,i)); % MaxNum shows the membership degree
    [row, col] = ind2sub(size(mmbrship_dgre_stop_density,1), maxIndex); % row shows MaxNum's row
    
    sentence_1=[sentence_1;stops(1,i),", is a stop where",line_nmber_stop(1,i)," lines pass and the density rate is ",s1_labels(1,row),maxNum];
end

%% 2. SENTENCE

% Density of this bus stop is the highest on "TUESDAY" and other days in order of density are as follows:'Friday','Saturday','Sunday'.

s2_labels = {'low','normal','high'}; % Daily density labels which membership calculated with fuzzy c-means clustering
days={'Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'};

daily_density=[];

for j=1:7 %Calculating daily density for each bus stop
    
    % calculating daily density for bus stop_10
    temp1=data10(1,j);
    temp1=table2array(temp1);
    temp2=data10(1,j+7);
    temp2=table2array(temp2);
    daily_density(1,j)=size(temp1,1)+ size(temp2,1);
    
    % calculating daily density for bus stop_17
    temp1=data17(1,j);
    temp1=table2array(temp1);
    temp2=data17(1,j+7);
    temp2=table2array(temp2);
    daily_density(2,j)=size(temp1,1)+ size(temp2,1);
    
    % calculating daily density for bus stop_1737
    temp1=data1737(1,j);
    temp1=table2array(temp1);
    temp2=data1737(1,j+7);
    temp2=table2array(temp2);
    daily_density(3,j)=size(temp1,1)+ size(temp2,1);
    
    % calculating daily density for bus stop_2771
    temp1=data2771(1,j);
    temp1=table2array(temp1);
    temp2=data2771(1,j+7);
    temp2=table2array(temp2);
    daily_density(4,j)=size(temp1,1)+ size(temp2,1);
        
end
daily_density(2,5)= round((daily_density(2,4)+ daily_density(2,6))/2);
daily_density(3,5)= round((daily_density(3,4)+ daily_density(3,6))/2);
daily_density(4,5)= round((daily_density(4,4)+ daily_density(4,6))/2);

sentence_2=[];
for i=1:size(stops,2)
        
    stop_daily_density=daily_density(i,:);
    [maxNum, maxIndex] = max(stop_daily_density(:,:)); % MaxNum shows the membership degree
    [row, col] = ind2sub(size(stop_daily_density,1), maxIndex); % row shows MaxNum's row
    
    [membership_degree]=fuzzy_c_means(daily_density(i,:)',3);
    membership_degree=sortrows(membership_degree,col); % this sorts matrix from the first coloumn and keep the rows same
    
    xx=[1,2,3,4,5,6,7;stop_daily_density];
    sorted_days=sortrows(xx',2);
    ad_days=[];
    
    for j=1:7
        
        mm=sorted_days(8-j,1);
        if mm~=col
            ad_days=[ad_days,days(1,mm)];
        end
        
    end
    
    sentence_2=[sentence_2;"Looking at the crowd on a daily basis, it is the highest on",days(1,col),'and other days in order of density are as follows:',ad_days,membership_degree(size(s2_labels,2),col)];
end

%% 3. Sentence

% During the week, the density is generally "LOW" in the "MORNINGS".

s3_labels = {'low','normal','high'}; % Hourly density labels which membership calculated with fuzzy c-means clustering

data10_hourly=[];
data17_hourly=[];
data1737_hourly=[];
data2771_hourly=[];

for i=1:12 %aggregating all days for each bus stop to detect hourly get-on. but only week, not weekend.
    
    if (i~=6) || (i~=7) 
        temp1=table2array(data10(1,i)); 
        data10_hourly=[data10_hourly;temp1];
        
        temp2=table2array(data17(1,i));
        data17_hourly=[data17_hourly;temp2];
        
        temp3=table2array(data1737(1,i));
        data1737_hourly=[data1737_hourly;temp3];
        
        temp4=table2array(data2771(1,i));
        data2771_hourly=[data2771_hourly;temp4];
    end
   
end

hourly_density=[]; % this matrix shows hourly get-on (hours: 06:00-07:00-...-23:00)
for j=1:18
    hourly_density(1,j)=[sum(data10_hourly(:,3)==(j+5))];
    hourly_density(2,j)=[sum(data17_hourly(:,3)==(j+5))];
    hourly_density(3,j)=[sum(data1737_hourly(:,3)==(j+5))];
    hourly_density(4,j)=[sum(data2771_hourly(:,3)==(j+5))];
end

sentence_3=[];
for i=1:size(stops,2)
    
    stop_hourly_density=hourly_density(i,:);    
    [maxNum, maxIndex] = max(stop_hourly_density(:,:)); % MaxNum shows the membership degree
    [row, col] = ind2sub(size(stop_hourly_density,1), maxIndex); % row shows MaxNum's row

    [membership_degree]=fuzzy_c_means(hourly_density(i,:)',3);
    membership_degree=sortrows(membership_degree,col); % this sorts matrix from the first coloumn and keep the rows same
    
    label_1=[]; % calculating Truth degre
    den=0; % counting denominator of truth degree
    for j=1:5 % counting hour based (6,7,8,9,10 for morning) 
        if j<5 % this is for 6,7,8,9 whose membership is 1.0
            tt1=min(1,membership_degree(1,j)); % calculating membership degree for "LOW" label
            tt2=min(1,membership_degree(2,j)); % calculating membership degree for "NORMAL" label
            tt3=min(1,membership_degree(3,j)); % calculating membership degree for "HIGH" label
            label_1(:,j)=[tt1;tt2;tt3];
            den=den+1;
        else % this is for 10 whose membership is 0.5
            tt1=min(0.5,membership_degree(1,j)); % calculating membership degree for "LOW" label
            tt2=min(0.5,membership_degree(2,j)); % calculating membership degree for "NORMAL" label
            tt3=min(0.5,membership_degree(3,j)); % calculating membership degree for "HIGH" label
            label_1(:,j)=[tt1;tt2;tt3]; 
            den=den+0.5;
        end
    end
    
    lbl_1=[((sum(label_1(1,:)))/den),((sum(label_1(2,:)))/den),((sum(label_1(3,:)))/den)]; % calculating total truth degree for each labels (L,M,H)
    [maxNum, maxIndex] = max(lbl_1(:,:)); % finding max truth degree
    
    sentence_3=[sentence_3;"During the week, hourly density is generally",s3_labels(1,maxIndex), "in the MORNINGS",maxNum];
end

%% 4. SENTENCE

% "It is "NORMAL" in the MIDDAY ..."

s4_labels = {'low','normal','high'}; % Hourly density labels which membership calculated with fuzzy c-means clustering

sentence_4=[];
for i=1:size(stops,2)
    
    stop_hourly_density=hourly_density(i,:);    
    [maxNum, maxIndex] = max(stop_hourly_density(:,:)); % MaxNum shows the membership degree
    [row, col] = ind2sub(size(stop_hourly_density,1), maxIndex); % row shows MaxNum's row

    [membership_degree]=fuzzy_c_means(hourly_density(i,:)',3);
    membership_degree=sortrows(membership_degree,col); % this sorts matrix from the first coloumn and keep the rows same
    
    label_1=[]; % calculating Truth degre
    den=0; % counting denominator of truth degree
    for j=1:6 % counting hour based (10,11,12,13,14,15 for morning) 
        if ((j+9)~=10) || ((j+9)~=15) % this is for 11,12,13,14 whose memebership is 1.0
            tt1=min(1,membership_degree(1,j+4)); % calculating membership degree for "LOW" label
            tt2=min(1,membership_degree(2,j+4)); % calculating membership degree for "NORMAL" label
            tt3=min(1,membership_degree(3,j+4)); % calculating membership degree for "HIGH" label
            label_1(:,j)=[tt1;tt2;tt3];
            den=den+1;
        else % this is for 10,15 whose membership is 0.5
            tt1=min(0.5,membership_degree(1,j+4)); % calculating membership degree for "LOW" label
            tt2=min(0.5,membership_degree(2,j+4)); % calculating membership degree for "NORMAL" label
            tt3=min(0.5,membership_degree(3,j+4)); % calculating membership degree for "HIGH" label
            label_1(:,j)=[tt1;tt2;tt3]; 
            den=den+0.5;
        end
    end
    
    lbl_1=[((sum(label_1(1,:)))/den),((sum(label_1(2,:)))/den),((sum(label_1(3,:)))/den)]; % calculating total truth degree for each labels (L,M,H)
    [maxNum, maxIndex] = max(lbl_1(:,:)); % finding max truth degree
    
    sentence_4=[sentence_4;"It is",s4_labels(1,maxIndex) ,"in the MIDDAY",maxNum];
end

%% 5. SENTENCE

% " and towards EVENING, it reaches "LOW" level."

s5_labels = {'low','normal','high'}; % Hourly density labels which membership calculated with fuzzy c-means clustering

sentence_5=[];
for i=1:size(stops,2)
    
    stop_hourly_density=hourly_density(i,:);    
    [maxNum, maxIndex] = max(stop_hourly_density(:,:)); % MaxNum shows the membership degree
    [row, col] = ind2sub(size(stop_hourly_density,1), maxIndex); % row shows MaxNum's row

    [membership_degree]=fuzzy_c_means(hourly_density(i,:)',3);
    membership_degree=sortrows(membership_degree,col); % this sorts matrix from the first coloumn and keep the rows same
    
    label_1=[]; % calculating Truth degre
    den=0; % counting denominator of truth degree
    for j=1:6 % counting hour based (15,16,17,18,19,20 for morning) 
        if ((j+14)~=15) || ((j+14)~=20) % this is for 16,17,18,19 whose memebership is 1.0
            tt1=min(1,membership_degree(1,j+9)); % calculating membership degree for "LOW" label
            tt2=min(1,membership_degree(2,j+9)); % calculating membership degree for "NORMAL" label
            tt3=min(1,membership_degree(3,j+9)); % calculating membership degree for "HIGH" label
            label_1(:,j)=[tt1;tt2;tt3];
            den=den+1;
        else % this is for 15,20 whose membership is 0.5
            tt1=min(0.5,membership_degree(1,j+9)); % calculating membership degree for "LOW" label
            tt2=min(0.5,membership_degree(2,j+9)); % calculating membership degree for "NORMAL" label
            tt3=min(0.5,membership_degree(3,j+9)); % calculating membership degree for "HIGH" label
            label_1(:,j)=[tt1;tt2;tt3]; 
            den=den+0.5;
        end
    end
    
    lbl_1=[((sum(label_1(1,:)))/den),((sum(label_1(2,:)))/den),((sum(label_1(3,:)))/den)]; % calculating total truth degree for each labels (L,M,H)
    [maxNum, maxIndex] = max(lbl_1(:,:)); % finding max truth degree
    
    sentence_5=[sentence_5;"and towards EVENING, it reaches",s5_labels(1,maxIndex),"level.",maxNum];
end

%% 6. SENTENCE

% "In the NIGHT, density has a "LOW" level."

s6_labels = {'low','normal','high'}; % Hourly density labels which membership calculated with fuzzy c-means clustering

sentence_6=[];
for i=1:size(stops,2)
    
    stop_hourly_density=hourly_density(i,:);    
    [maxNum, maxIndex] = max(stop_hourly_density(:,:)); % MaxNum shows the membership degree
    [row, col] = ind2sub(size(stop_hourly_density,1), maxIndex); % row shows MaxNum's row

    [membership_degree]=fuzzy_c_means(hourly_density(i,:)',3);
    membership_degree=sortrows(membership_degree,col); % this sorts matrix from the first coloumn and keep the rows same
    
    label_1=[]; % calculating Truth degre
    den=0; % counting denominator of truth degree
    for j=1:4 % counting hour based (20,21,22,23 for morning) 
        if (j+19)~=20 % this is for 21,22,23 whose memebership is 1.0
            tt1=min(1,membership_degree(1,j+14)); % calculating membership degree for "LOW" label
            tt2=min(1,membership_degree(2,j+14)); % calculating membership degree for "NORMAL" label
            tt3=min(1,membership_degree(3,j+14)); % calculating membership degree for "HIGH" label
            label_1(:,j)=[tt1;tt2;tt3];
            den=den+1;
        else % this is for 20 whose membership is 0.5
            tt1=min(0.5,membership_degree(1,j+14)); % calculating membership degree for "LOW" label
            tt2=min(0.5,membership_degree(2,j+14)); % calculating membership degree for "NORMAL" label
            tt3=min(0.5,membership_degree(3,j+14)); % calculating membership degree for "HIGH" label
            label_1(:,j)=[tt1;tt2;tt3]; 
            den=den+0.5;
        end
    end
    
    lbl_1=[((sum(label_1(1,:)))/den),((sum(label_1(2,:)))/den),((sum(label_1(3,:)))/den)]; % calculating total truth degree for each labels (L,M,H)
    [maxNum, maxIndex] = max(lbl_1(:,:)); % finding max truth degree
    
    sentence_6=[sentence_6;"In the NIGHT, density is at a ",s6_labels(1,maxIndex)," level",maxNum];
end

%% 7. SENTENCE

% "The busiest hour of the stop is "17:00", with "1147" boardings."

sentence_7=[];
for i=1:size(stops,2)
    
    stop_hourly_density=hourly_density(i,:);    
    [maxNum, maxIndex] = max(stop_hourly_density(:,:)); % MaxNum shows the membership degree
 
    sentence_7=[sentence_7;"The busiest hour of the stop is",(maxIndex+5),":00 clock, with ",maxNum,"boardings",1];
end

%% 8. SENTENCE

% "However, the density during the day is slightly different on the weekend. Just like on weekdays, the density is  "LOW" in the MORNINGS. "
% "However, the density during the day is slightly different on the weekend. Unlike on weekdays, the density is  "LOW" in the MORNINGS. "
s8_labels = {'low','normal','high'}; % Hourly density labels which membership calculated with fuzzy c-means clustering

data10_hourly=[];
data17_hourly=[];
data1737_hourly=[];
data2771_hourly=[];

for i=1:14 %aggregating all days for each bus stop to detect hourly get-on. but only week, not weekend.
    
    if (i==6) || (i==7)|| (i==13)|| (i==14) 
        temp1=table2array(data10(1,i)); 
        data10_hourly=[data10_hourly;temp1];
        
        temp2=table2array(data17(1,i));
        data17_hourly=[data17_hourly;temp2];
        
        temp3=table2array(data1737(1,i));
        data1737_hourly=[data1737_hourly;temp3];
        
        temp4=table2array(data2771(1,i));
        data2771_hourly=[data2771_hourly;temp4];
    end
   
end

hourly_density=[]; % this matrix shows hourly get-on (hours: 06:00-07:00-...-23:00)
for j=1:18
    hourly_density(1,j)=[sum(data10_hourly(:,3)==(j+5))];
    hourly_density(2,j)=[sum(data17_hourly(:,3)==(j+5))];
    hourly_density(3,j)=[sum(data1737_hourly(:,3)==(j+5))];
    hourly_density(4,j)=[sum(data2771_hourly(:,3)==(j+5))];
end

sentence_8=[];
for i=1:size(stops,2)
    
    stop_hourly_density=hourly_density(i,:);    
    [maxNum, maxIndex] = max(stop_hourly_density(:,:)); % MaxNum shows the membership degree
    [row, col] = ind2sub(size(stop_hourly_density,1), maxIndex); % row shows MaxNum's row

    [membership_degree]=fuzzy_c_means(hourly_density(i,:)',3);
    membership_degree=sortrows(membership_degree,col); % this sorts matrix from the first coloumn and keep the rows same
    
    label_1=[]; % calculating Truth degre
    den=0; % counting denominator of truth degree
    for j=1:5 % counting hour based (6,7,8,9,10 for morning) 
        if j<5 % this is for 6,7,8,9 whose membership is 1.0
            tt1=min(1,membership_degree(1,j)); % calculating membership degree for "LOW" label
            tt2=min(1,membership_degree(2,j)); % calculating membership degree for "NORMAL" label
            tt3=min(1,membership_degree(3,j)); % calculating membership degree for "HIGH" label
            label_1(:,j)=[tt1;tt2;tt3];
            den=den+1;
        else % this is for 10 whose membership is 0.5
            tt1=min(0.5,membership_degree(1,j)); % calculating membership degree for "LOW" label
            tt2=min(0.5,membership_degree(2,j)); % calculating membership degree for "NORMAL" label
            tt3=min(0.5,membership_degree(3,j)); % calculating membership degree for "HIGH" label
            label_1(:,j)=[tt1;tt2;tt3]; 
            den=den+0.5;
        end
    end
    
    lbl_1=[((sum(label_1(1,:)))/den),((sum(label_1(2,:)))/den),((sum(label_1(3,:)))/den)]; % calculating total truth degree for each labels (L,M,H)
    [maxNum, maxIndex] = max(lbl_1(:,:)); % finding max truth degree
    
    if (sentence_3(1,2))== s8_labels(1,maxIndex)
        sentence_8=[sentence_8;"At the weekend, just like on weekdays, the density is",s8_labels(1,maxIndex), "in the MORNINGS",maxNum];
    else
        sentence_8=[sentence_8;"However, the density during the day is slightly different on the weekend. Unlike weekdays, the density is",s8_labels(1,maxIndex), "in the MORNINGS",maxNum];
    end
end

%% 9. SENTENCE

% "It is "NORMAL" in the MIDDAY ..."

s9_labels = {'low','normal','high'}; % Hourly density labels which membership calculated with fuzzy c-means clustering

sentence_9=[];
for i=1:size(stops,2)
    
    stop_hourly_density=hourly_density(i,:);    
    [maxNum, maxIndex] = max(stop_hourly_density(:,:)); % MaxNum shows the membership degree
    [row, col] = ind2sub(size(stop_hourly_density,1), maxIndex); % row shows MaxNum's row

    [membership_degree]=fuzzy_c_means(hourly_density(i,:)',3);
    membership_degree=sortrows(membership_degree,col); % this sorts matrix from the first coloumn and keep the rows same
    
    label_1=[]; % calculating Truth degre
    den=0; % counting denominator of truth degree
    for j=1:6 % counting hour based (10,11,12,13,14,15 for morning) 
        if ((j+9)==10) || ((j+9)==15) % counting hour based (10,11,12,13,14,15 for morning) 
            tt1=min(0.5,membership_degree(1,j+4)); % calculating membership degree for "LOW" label
            tt2=min(0.5,membership_degree(2,j+4)); % calculating membership degree for "NORMAL" label
            tt3=min(0.5,membership_degree(3,j+4)); % calculating membership degree for "HIGH" label
            label_1(:,j)=[tt1;tt2;tt3];
            den=den+0.5;
        else % this is for 11,12,13,14 whose memebership is 1.0 
            tt1=min(1,membership_degree(1,j+4)); % calculating membership degree for "LOW" label
            tt2=min(1,membership_degree(2,j+4)); % calculating membership degree for "NORMAL" label
            tt3=min(1,membership_degree(3,j+4)); % calculating membership degree for "HIGH" label
            label_1(:,j)=[tt1;tt2;tt3];
            den=den+1;
        end
    end
    
    lbl_1=[((sum(label_1(1,:)))/den),((sum(label_1(2,:)))/den),((sum(label_1(3,:)))/den)]; % calculating total truth degree for each labels (L,M,H)
    [maxNum, maxIndex] = max(lbl_1(:,:)); % finding max truth degree
    
    sentence_9=[sentence_9;"It is",s9_labels(1,maxIndex) ,"in the MIDDAY",maxNum];
end

%% 10. SENTENCE

% " and towards EVENING, it reaches "LOW" level."

s10_labels = {'low','normal','high'}; % Hourly density labels which membership calculated with fuzzy c-means clustering

sentence_10=[];
for i=1:size(stops,2)
    
    stop_hourly_density=hourly_density(i,:);    
    [maxNum, maxIndex] = max(stop_hourly_density(:,:)); % MaxNum shows the membership degree
    [row, col] = ind2sub(size(stop_hourly_density,1), maxIndex); % row shows MaxNum's row

    [membership_degree]=fuzzy_c_means(hourly_density(i,:)',3);
    membership_degree=sortrows(membership_degree,col); % this sorts matrix from the first coloumn and keep the rows same
    
    label_1=[]; % calculating Truth degre
    den=0; % counting denominator of truth degree
    for j=1:6 % counting hour based (15,16,17,18,19,20 for morning) 
        if ((j+14)==15) || ((j+14)==20) % this is for 15,20 whose membership is 0.5 
            tt1=min(0.5,membership_degree(1,j+9)); % calculating membership degree for "LOW" label
            tt2=min(0.5,membership_degree(2,j+9)); % calculating membership degree for "NORMAL" label
            tt3=min(0.5,membership_degree(3,j+9)); % calculating membership degree for "HIGH" label
            label_1(:,j)=[tt1;tt2;tt3];
            den=den+0.5;
        else % this is for 16,17,18,19 whose memebership is 1.0
            tt1=min(1,membership_degree(1,j+9)); % calculating membership degree for "LOW" label
            tt2=min(1,membership_degree(2,j+9)); % calculating membership degree for "NORMAL" label
            tt3=min(1,membership_degree(3,j+9)); % calculating membership degree for "HIGH" label
            label_1(:,j)=[tt1;tt2;tt3]; 
            den=den+1;
        end
    end
    
    lbl_1=[((sum(label_1(1,:)))/den),((sum(label_1(2,:)))/den),((sum(label_1(3,:)))/den)]; % calculating total truth degree for each labels (L,M,H)
    [maxNum, maxIndex] = max(lbl_1(:,:)); % finding max truth degree
    
    sentence_10=[sentence_10;"and towards EVENING, it reaches",s10_labels(1,maxIndex),"level.",maxNum];
end

%% 11. SENTENCE

% "In the NIGHT, density has a "LOW" level."

s11_labels = {'low','normal','high'}; % Hourly density labels which membership calculated with fuzzy c-means clustering

sentence_11=[];
for i=1:size(stops,2)
    
    stop_hourly_density=hourly_density(i,:);    
    [maxNum, maxIndex] = max(stop_hourly_density(:,:)); % MaxNum shows the membership degree
    [row, col] = ind2sub(size(stop_hourly_density,1), maxIndex); % row shows MaxNum's row

    [membership_degree]=fuzzy_c_means(hourly_density(i,:)',3);
    membership_degree=sortrows(membership_degree,col); % this sorts matrix from the first coloumn and keep the rows same
    
    label_1=[]; % calculating Truth degre
    den=0; % counting denominator of truth degree
    for j=1:4 % counting hour based (20,21,22,23 for morning) 
        if (j+19)~=20 % this is for 21,22,23 whose memebership is 1.0
            tt1=min(1,membership_degree(1,j+14)); % calculating membership degree for "LOW" label
            tt2=min(1,membership_degree(2,j+14)); % calculating membership degree for "NORMAL" label
            tt3=min(1,membership_degree(3,j+14)); % calculating membership degree for "HIGH" label
            label_1(:,j)=[tt1;tt2;tt3];
            den=den+1;
        else % this is for 20 whose membership is 0.5
            tt1=min(0.5,membership_degree(1,j+14)); % calculating membership degree for "LOW" label
            tt2=min(0.5,membership_degree(2,j+14)); % calculating membership degree for "NORMAL" label
            tt3=min(0.5,membership_degree(3,j+14)); % calculating membership degree for "HIGH" label
            label_1(:,j)=[tt1;tt2;tt3]; 
            den=den+0.5;
        end
    end
    
    lbl_1=[((sum(label_1(1,:)))/den),((sum(label_1(2,:)))/den),((sum(label_1(3,:)))/den)]; % calculating total truth degree for each labels (L,M,H)
    [maxNum, maxIndex] = max(lbl_1(:,:)); % finding max truth degree
    
    sentence_11=[sentence_11;"In the NIGHT, it is at ",s11_labels(1,maxIndex)," level",maxNum];
end

%% 12. SENTENCE

% "The busiest hour of the stop is "17:00", with "1147" boardings."

sentence_12=[];
for i=1:size(stops,2)
    
    stop_hourly_density=hourly_density(i,:);    
    [maxNum, maxIndex] = max(stop_hourly_density(:,:)); % MaxNum shows the membership degree
 
    sentence_12=[sentence_12;"The busiest hour of the stop is",(maxIndex+5),":00 clock, with ",maxNum,"boardings at the weekends",1];
end

%% 13. SENTENCE

% "At this bus stop, the most seen passenger type is Full Card with 113 boarding."

s13_labels = {'full','discounted','free'};

data10_card=[];
data17_card=[];
data1737_card=[];
data2771_card=[];

sentence_13=[];

for i=1:14 %aggregating all days to count each card type boarding
    temp1=table2array(data10(1,i)); 
    data10_card=[data10_card;temp1];

    temp2=table2array(data17(1,i));
    data17_card=[data17_card;temp2];

    temp3=table2array(data1737(1,i));
    data1737_card=[data1737_card;temp3];

    temp4=table2array(data2771(1,i));
    data2771_card=[data2771_card;temp4];
end

card_types=[]; % this matrix shows card type boarding

for i=1:size(s13_labels,2)
    varble=2^(3-i); % this is for finding 25, 50, 100; those are cards code in data
    card_types(1,i)=[sum(data10_card(:,5)==(varble*25))];
    card_types(2,i)=[sum(data17_card(:,5)==(varble*25))];
    card_types(3,i)=[sum(data1737_card(:,5)==(varble*25))];
    card_types(4,i)=[sum(data2771_card(:,5)==(varble*25))];
end

card_name=[];
for j=1:size(stops,2)  
    [maxNum, maxIndex] = max(card_types(j,:));
    card_name=[card_name,s13_labels(1,maxIndex)];
    sentence_13=[sentence_13;"At this bus stop, the most seen passenger type is ",s13_labels(1,maxIndex),"card with",maxNum,"boarding.",1];
end

%% 14. SENTENCE

% "The "HIGHEST" density of this card type is seen in the "EVENING" hours, especially at "17:00"."

s14_labels = {'full','discounted','free'};
day_parts= {'Morning','Midday','Evening','Night'};

data10_hourly=[];
data17_hourly=[];
data1737_hourly=[];
data2771_hourly=[];

for i=1:14 %aggregating all days for each bus stop to detect hourly get-on.
    
        temp1=table2array(data10(1,i)); 
        data10_hourly=[data10_hourly;temp1];
        
        temp2=table2array(data17(1,i));
        data17_hourly=[data17_hourly;temp2];
        
        temp3=table2array(data1737(1,i));
        data1737_hourly=[data1737_hourly;temp3];
        
        temp4=table2array(data2771(1,i));
        data2771_hourly=[data2771_hourly;temp4];  
end

card_via_hours=[];

for i=1:18 % for Data_10
    card_via_hours(1,i)=[sum(data10_hourly(:,3)==(i+5)& data10_hourly(:,5)==(100))]; 
    card_via_hours(2,i)=[sum(data17_hourly(:,3)==(i+5)& data17_hourly(:,5)==(100))];
    card_via_hours(3,i)=[sum(data1737_hourly(:,3)==(i+5)& data1737_hourly(:,5)==(100))];
    card_via_hours(4,i)=[sum(data2771_hourly(:,3)==(i+5)& data2771_hourly(:,5)==(100))];
 end


sentence_14=[];
for i=1:size(stops,2)
    
    stop_card_via_hours=card_via_hours(i,:);    
    [maxNum, maxIndex] = max(stop_card_via_hours(:,:)); % MaxNum shows the membership degree
    [row, col] = ind2sub(size(card_via_hours,1), maxIndex); % row shows MaxNum's row

    [membership_degree]=fuzzy_c_means(card_via_hours(i,:)',3);
    membership_degree=sortrows(membership_degree,maxIndex); % this sorts matrix from the first coloumn and keep the rows same
    
    label_1=[]; % calculating Truth degre
    den=0; % counting denominator of truth degree
    for j=1:5 % counting hour based (6,7,8,9,10 for morning) 
        if j<5 % this is for 6,7,8,9 whose membership is 1.0
            tt1=min(1,membership_degree(1,j)); % calculating membership degree for "LOW" label
            tt2=min(1,membership_degree(2,j)); % calculating membership degree for "NORMAL" label
            tt3=min(1,membership_degree(3,j)); % calculating membership degree for "HIGH" label
            label_1(:,j)=[tt1;tt2;tt3];
            den=den+1;
        else % this is for 10 whose membership is 0.5
            tt1=min(0.5,membership_degree(1,j)); % calculating membership degree for "LOW" label
            tt2=min(0.5,membership_degree(2,j)); % calculating membership degree for "NORMAL" label
            tt3=min(0.5,membership_degree(3,j)); % calculating membership degree for "HIGH" label
            label_1(:,j)=[tt1;tt2;tt3]; 
            den=den+0.5;
        end
    end
    
    lbl_1=[((sum(label_1(1,:)))/den),((sum(label_1(2,:)))/den),((sum(label_1(3,:)))/den)]; % calculating total truth degree for each labels (L,M,H)
    
    label_2=[]; % calculating Truth degre
    den=0; % counting denominator of truth degree
    for j=1:6 % counting hour based (10,11,12,13,14,15 for morning) 
        if ((j+9)==10) || ((j+9)==15) % counting hour based (10,11,12,13,14,15 for morning) 
            tt1=min(0.5,membership_degree(1,j+4)); % calculating membership degree for "LOW" label
            tt2=min(0.5,membership_degree(2,j+4)); % calculating membership degree for "NORMAL" label
            tt3=min(0.5,membership_degree(3,j+4)); % calculating membership degree for "HIGH" label
            label_2(:,j)=[tt1;tt2;tt3];
            den=den+0.5;
        else % this is for 11,12,13,14 whose memebership is 1.0 
            tt1=min(1,membership_degree(1,j+4)); % calculating membership degree for "LOW" label
            tt2=min(1,membership_degree(2,j+4)); % calculating membership degree for "NORMAL" label
            tt3=min(1,membership_degree(3,j+4)); % calculating membership degree for "HIGH" label
            label_2(:,j)=[tt1;tt2;tt3];
            den=den+1;
        end
    end
    
    lbl_2=[((sum(label_2(1,:)))/den),((sum(label_2(2,:)))/den),((sum(label_2(3,:)))/den)]; % calculating total truth degree for each labels (L,M,H)
 
    label_3=[]; % calculating Truth degre
    den=0; % counting denominator of truth degree
    for j=1:6 % counting hour based (15,16,17,18,19,20 for morning)
        if ((j+14)==15) || ((j+14)==20) % this is for 15,20 whose membership is 0.5
            tt1=min(0.5,membership_degree(1,j+9)); % calculating membership degree for "LOW" label
            tt2=min(0.5,membership_degree(2,j+9)); % calculating membership degree for "NORMAL" label
            tt3=min(0.5,membership_degree(3,j+9)); % calculating membership degree for "HIGH" label
            label_3(:,j)=[tt1;tt2;tt3];
            den=den+0.5;
        else % this is for 16,17,18,19 whose memebership is 1.0 
            tt1=min(1,membership_degree(1,j+9)); % calculating membership degree for "LOW" label
            tt2=min(1,membership_degree(2,j+9)); % calculating membership degree for "NORMAL" label
            tt3=min(1,membership_degree(3,j+9)); % calculating membership degree for "HIGH" label
            label_3(:,j)=[tt1;tt2;tt3];
            den=den+1;
        end
    end
    
    lbl_3=[((sum(label_3(1,:)))/den),((sum(label_3(2,:)))/den),((sum(label_3(3,:)))/den)]; % calculating total truth degree for each labels (L,M,H)
 
    
    label_4=[]; % calculating Truth degre
    den=0; % counting denominator of truth degree
    for j=1:4 % counting hour based (20,21,22,23 for morning) 
        if (j+19)~=20 % this is for 21,22,23 whose memebership is 1.0
            tt1=min(1,membership_degree(1,j+14)); % calculating membership degree for "LOW" label
            tt2=min(1,membership_degree(2,j+14)); % calculating membership degree for "NORMAL" label
            tt3=min(1,membership_degree(3,j+14)); % calculating membership degree for "HIGH" label
            label_4(:,j)=[tt1;tt2;tt3];
            den=den+1;
        else % this is for 20 whose membership is 0.5
            tt1=min(0.5,membership_degree(1,j+14)); % calculating membership degree for "LOW" label
            tt2=min(0.5,membership_degree(2,j+14)); % calculating membership degree for "NORMAL" label
            tt3=min(0.5,membership_degree(3,j+14)); % calculating membership degree for "HIGH" label
            label_4(:,j)=[tt1;tt2;tt3]; 
            den=den+0.5;
        end
    end
    
    lbl_4=[((sum(label_4(1,:)))/den),((sum(label_4(2,:)))/den),((sum(label_4(3,:)))/den)]; % calculating total truth degree for each labels (L,M,H)
    
    lbl_all=[lbl_1;lbl_2;lbl_3;lbl_4]; % collecting all part days' membership for HIGH label
    [maxNumlbl, maxIndexlbl] = max(lbl_all(:,3)); % MaxIndexlbl gives day parts and maxNumlbl gives membership degree
    sentence_14=[sentence_14;"The HIGHEST density of this card type is seen in the ",day_parts(1,maxIndexlbl),"hours, especially at",(maxIndex+5),":00.",maxNumlbl];
end

%% 15. SENTENCE

% "and mostly prefers the E75 line."

s15_labels = {'full','discounted','free'};

data10_line=[];
data17_line=[];
data1737_line=[];
data2771_line=[];

for i=1:14 %aggregating all days for each bus stop to detect lines.
    
        temp1=table2array(data10(1,i)); 
        data10_line=[data10_line;temp1];
        
        temp2=table2array(data17(1,i));
        data17_line=[data17_line;temp2];
        
        temp3=table2array(data1737(1,i));
        data1737_line=[data1737_line;temp3];
        
        temp4=table2array(data2771(1,i));
        data2771_line=[data2771_line;temp4];  
end

most_freq_line=[mode(data10_line(:,4)),mode(data17_line(:,4)),mode(data1737_line(:,4)),mode(data2771_line(:,4))];
sentence_15=[];
for j=1:size(stops,2)
    
    sentence_15=[sentence_15;"and mostly prefers the ",most_freq_line(1,j)," line ",1];  
    
end

%% 16. SENTENCE

% While the density of discounted card types is at a normal level, Free type is at low level..

s16_labels = {'full','discounted','free'}; 

card_name=[];
sentence_16=[];
for j=1:size(stops,2)  
    [minNum, minIndex] = min(card_types(j,:)); % looking for min value "low"
    card_name=[card_name,s13_labels(1,minIndex)];
    
    [roww, colmn] = find(card_types(1,:) == median(card_types(1,:))); % looking for "normal" value

    sentence_16=[sentence_16;"While the density of ",s16_labels(1,colmn)," card types is at a normal level, ",s16_labels(1,minIndex)," type has a low level with",minNum,"boarding.",1];
end


%% 17. SENTENCE

% "While the lines with the high level density at the stop are E75 and E75, the lines with the low levels are R56, R67."

s17_labels = {'low','normal','high'}; % Hourly density labels which membership calculated with fuzzy c-means clustering

freq_line_10=unique(data10_temp(:,1));
freq_line_17=unique(data17_temp(:,1));
freq_line_1737=unique(data1737_temp(:,1));
freq_line_2771=unique(data2771_temp(:,1));

for i=1:size(freq_line_10,1) % this counting line frequency in bus stop
    freq_line_10(i,2)=sum(data10_line(:,4)==freq_line_10(i,1)); 
end
for i=1:size(freq_line_17,1) % this counting line frequency in bus stop
    freq_line_17(i,2)=sum(data17_line(:,4)==freq_line_17(i,1)); 
end
for i=1:size(freq_line_1737,1) % this counting line frequency in bus stop
    freq_line_1737(i,2)=sum(data1737_line(:,4)==freq_line_1737(i,1)); 
end
for i=1:size(freq_line_2771,1) % this counting line frequency in bus stop
    freq_line_2771(i,2)=sum(data2771_line(:,4)==freq_line_2771(i,1)); 
end

sentence_17=[];
%%% for bus stop_10
stop_card_via_hours=freq_line_10(:,2);    
[maxNum, maxIndex] = max(stop_card_via_hours(:,:)); % MaxNum shows the membership degree
[membership_degree]=fuzzy_c_means(freq_line_10(:,2),3);
membership_degree=sortrows(membership_degree,maxIndex); % this sorts matrix from the first coloumn and keep the rows same
combined=[freq_line_10';membership_degree]; % combine in the same matrix to sort
sorted_combined=sortrows(combined',2); % sorted according to freq.

high_level_line=sorted_combined(size(freq_line_10,1),1);
low_level_line=sorted_combined(1,1);
truth=min(sorted_combined(size(freq_line_10,1),5),sorted_combined(1,3));
t_10=sorted_combined(size(freq_line_10,1),5); % this is for sentence 18

sentence_17=[sentence_17;"In terms of lines, the busiest at the stop is line ",high_level_line,", while line",low_level_line,"has a low level.",truth];

%%% for bus stop_17
stop_card_via_hours=freq_line_17(:,2);    
[maxNum, maxIndex] = max(stop_card_via_hours(:,:)); % MaxNum shows the membership degree
[membership_degree]=fuzzy_c_means(freq_line_17(:,2),3);
membership_degree=sortrows(membership_degree,maxIndex); % this sorts matrix from the first coloumn and keep the rows same
combined=[freq_line_17';membership_degree]; % combine in the same matrix to sort
sorted_combined=sortrows(combined',2); % sorted according to freq.

high_level_line=sorted_combined(size(freq_line_17,1),1);
low_level_line=sorted_combined(1,1);
truth=min(sorted_combined(size(freq_line_17,1),5),sorted_combined(1,3));
t_17=sorted_combined(size(freq_line_17,1),5); % this is for sentence 18

sentence_17=[sentence_17;"In terms of lines, the busiest at the stop is line ",high_level_line,", while line",low_level_line,"has a low level.",truth];

%%% for bus stop_1737
stop_card_via_hours=freq_line_1737(:,2);    
[maxNum, maxIndex] = max(stop_card_via_hours(:,:)); % MaxNum shows the membership degree
[membership_degree]=fuzzy_c_means(freq_line_1737(:,2),3);
membership_degree=sortrows(membership_degree,maxIndex); % this sorts matrix from the first coloumn and keep the rows same
combined=[freq_line_1737';membership_degree]; % combine in the same matrix to sort
sorted_combined=sortrows(combined',2); % sorted according to freq.

high_level_line=sorted_combined(size(freq_line_1737,1),1);
low_level_line=sorted_combined(1,1);
truth=min(sorted_combined(size(freq_line_1737,1),5),sorted_combined(1,3));
t_1737=sorted_combined(size(freq_line_1737,1),5); % this is for sentence 18

sentence_17=[sentence_17;"In terms of lines, the busiest at the stop is line ",high_level_line,", while line",low_level_line,"has a low level.",truth];

%%% for bus stop_2771
stop_card_via_hours=freq_line_2771(:,2);    
[maxNum, maxIndex] = max(stop_card_via_hours(:,:)); % MaxNum shows the membership degree
[membership_degree]=fuzzy_c_means(freq_line_2771(:,2),3);
membership_degree=sortrows(membership_degree,maxIndex); % this sorts matrix from the first coloumn and keep the rows same
combined=[freq_line_2771';membership_degree]; % combine in the same matrix to sort
sorted_combined=sortrows(combined',2); % sorted according to freq.

high_level_line=sorted_combined(size(freq_line_2771,1),1);
low_level_line=sorted_combined(1,1);
truth=min(sorted_combined(size(freq_line_2771,1),5),sorted_combined(1,3));
t_2771=sorted_combined(size(freq_line_2771,1),5); % this is for sentence 18

sentence_17=[sentence_17;"In terms of lines, the busiest at the stop is line ",high_level_line,", while line",low_level_line,"has a low level.",truth];

%% SENTENCE 18

% "As a summary, the highest level of the stop's density during the week is on
% the E75 line around 17:00 on Tuesday and mostly Full card type passengers are seen."

truthh=[t_10,t_17,t_1737,t_2771];
sentence_18=[];
for j=1:size(stops,2)
    truth_18=min(truthh(1,j),str2double(sentence_2(j,10)));
    sentence_18=[sentence_18;"As a summary, the highest level of the stop's density during the week is on the ",sentence_17(j,2),"line on around ",sentence_7(j,2),":00 on ",sentence_2(j,2),"and mostly ",sentence_13(j,2),"card type passengers are seen.",truth_18];  

end

%% ALL SENTENCES

% combining all sentences
sentencesall{1}=sentence_1;
sentencesall{2}=sentence_2;
sentencesall{3}=sentence_3;
sentencesall{4}=sentence_4;
sentencesall{5}=sentence_5;
sentencesall{6}=sentence_6;
sentencesall{7}=sentence_7;
sentencesall{8}=sentence_8;
sentencesall{9}=sentence_9;
sentencesall{10}=sentence_10;
sentencesall{11}=sentence_11;
sentencesall{12}=sentence_12;
sentencesall{13}=sentence_13;
sentencesall{14}=sentence_14;
sentencesall{15}=sentence_15;
sentencesall{16}=sentence_16;
sentencesall{17}=sentence_17;
sentencesall{18}=sentence_18;

TD_10=[];
TD_17=[];
TD_1737=[];
TD_2771=[];
temp=[];

for j=1:18
    temp=table2array(sentencesall(1,j));
    allsentences10(j,1:(size(temp,2)-1))=cellstr(temp(1,1:(size(temp,2)-1)));
    TD_10=[TD_10,str2num(temp(1,size(temp,2)))];
    allsentences17(j,1:(size(temp,2)-1))=cellstr(temp(2,1:(size(temp,2)-1)));
    TD_17=[TD_17,str2num(temp(2,size(temp,2)))];
    allsentences1373(j,1:(size(temp,2)-1))=cellstr(temp(3,1:(size(temp,2)-1)));
    TD_1737=[TD_1737,str2num(temp(3,size(temp,2)))];
    allsentences2771(j,1:(size(temp,2)-1))=cellstr(temp(4,1:(size(temp,2)-1)));
    TD_2771=[TD_2771,str2num(temp(4,size(temp,2)))];
end
truth_degree_10=min(TD_10);
truth_degree_17=min(TD_17);
truth_degree_1737=min(TD_1737);
truth_degree_2771=min(TD_2771);

%% GENERAL SUMMARIES
% 19. SENTENCES

% When considered according to these four stops chosen heterogeneously throughout Kayseri province; While the "highest" density throughout the week is seen on "Tuesday",.

s19_labels = {'low','normal','high'}; % Daily density labels which membership calculated with fuzzy c-means clustering
days={'Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'}

daily_density_all=[];

for i=1:7
    daily_density_all=[daily_density_all,sum(daily_density(:,i))];  
end


sentence_19=[];
        
stop_daily_density=daily_density_all(1,:);
[maxNum, maxIndex] = max(stop_daily_density(:,:)); % MaxNum shows the membership degree
[row, col] = ind2sub(size(stop_daily_density,1), maxIndex); % row shows MaxNum's row

[membership_degree]=fuzzy_c_means(daily_density_all(1,:)',3);
membership_degree=sortrows(membership_degree,col); % this sorts matrix from the first coloumn and keep the rows same

xx=[1,2,3,4,5,6,7;stop_daily_density];
sorted_days=sortrows(xx',2);
ad_days=[];

for j=1:7

    mm=sorted_days(8-j,1);
    if mm~=col
        ad_days=[ad_days,days(1,mm)];
    end

end

sentence_19=[sentence_19;"When considered according to these four stops chosen heterogeneously throughout Kayseri province; While the highest density throughout the week is seen on",days(1,col),'and other days in order of density are as follows:',ad_days,membership_degree(size(s19_labels,2),col)];

%% 20. SENTENCE

% The intensity during the day is generally low in the mornings.

s20_labels = {'low','normal','high'}; % Hourly density labels which membership calculated with fuzzy c-means clustering

data_hourly=[];

for i=1:14 %aggregating all days for each bus stop to detect hourly get-on. but only week, not weekend.

    temp1=table2array(data10(1,i)); 
    data_hourly=[data_hourly;temp1];

    temp2=table2array(data17(1,i));
    data_hourly=[data_hourly;temp2];

    temp3=table2array(data1737(1,i));
    data_hourly=[data_hourly;temp3];

    temp4=table2array(data2771(1,i));
    data_hourly=[data_hourly;temp4];

end

hourly_density=[]; % this matrix shows hourly get-on (hours: 06:00-07:00-...-23:00)
for j=1:18
    hourly_density(1,j)=[sum(data_hourly(:,3)==(j+5))];
end

sentence_20=[];
    
stop_hourly_density=hourly_density(1,:);    
[maxNum, maxIndex] = max(stop_hourly_density(:,:)); % MaxNum shows the membership degree
[row, col] = ind2sub(size(stop_hourly_density,1), maxIndex); % row shows MaxNum's row

[membership_degree]=fuzzy_c_means(hourly_density(1,:)',3);
membership_degree=sortrows(membership_degree,col); % this sorts matrix from the first coloumn and keep the rows same

label_1=[]; % calculating Truth degre
den=0; % counting denominator of truth degree
for j=1:5 % counting hour based (6,7,8,9,10 for morning) 
    if j<5 % this is for 6,7,8,9 whose membership is 1.0
        tt1=min(1,membership_degree(1,j)); % calculating membership degree for "LOW" label
        tt2=min(1,membership_degree(2,j)); % calculating membership degree for "NORMAL" label
        tt3=min(1,membership_degree(3,j)); % calculating membership degree for "HIGH" label
        label_1(:,j)=[tt1;tt2;tt3];
        den=den+1;
    else % this is for 10 whose membership is 0.5
        tt1=min(0.5,membership_degree(1,j)); % calculating membership degree for "LOW" label
        tt2=min(0.5,membership_degree(2,j)); % calculating membership degree for "NORMAL" label
        tt3=min(0.5,membership_degree(3,j)); % calculating membership degree for "HIGH" label
        label_1(:,j)=[tt1;tt2;tt3]; 
        den=den+0.5;
    end
end

lbl_1=[((sum(label_1(1,:)))/den),((sum(label_1(2,:)))/den),((sum(label_1(3,:)))/den)]; % calculating total truth degree for each labels (L,M,H)
[maxNum, maxIndex] = max(lbl_1(:,:)); % finding max truth degree

sentence_20=[sentence_20;"The density during the day is generally",s20_labels(1,maxIndex), "in the MORNINGS",maxNum];

%% 21 SENTENCE

% "It is "NORMAL" in the MIDDAY ..."

s21_labels = {'low','normal','high'}; % Hourly density labels which membership calculated with fuzzy c-means clustering

sentence_21=[];

stop_hourly_density=hourly_density(1,:);    
[maxNum, maxIndex] = max(stop_hourly_density(:,:)); % MaxNum shows the membership degree
[row, col] = ind2sub(size(stop_hourly_density,1), maxIndex); % row shows MaxNum's row

[membership_degree]=fuzzy_c_means(hourly_density(1,:)',3);
membership_degree=sortrows(membership_degree,col); % this sorts matrix from the first coloumn and keep the rows same

label_1=[]; % calculating Truth degre
den=0; % counting denominator of truth degree
for j=1:6 % counting hour based (10,11,12,13,14,15 for morning) 
    if ((j+9)~=10) || ((j+9)~=15) % this is for 11,12,13,14 whose memebership is 1.0
        tt1=min(1,membership_degree(1,j+4)); % calculating membership degree for "LOW" label
        tt2=min(1,membership_degree(2,j+4)); % calculating membership degree for "NORMAL" label
        tt3=min(1,membership_degree(3,j+4)); % calculating membership degree for "HIGH" label
        label_1(:,j)=[tt1;tt2;tt3];
        den=den+1;
    else % this is for 10,15 whose membership is 0.5
        tt1=min(0.5,membership_degree(1,j+4)); % calculating membership degree for "LOW" label
        tt2=min(0.5,membership_degree(2,j+4)); % calculating membership degree for "NORMAL" label
        tt3=min(0.5,membership_degree(3,j+4)); % calculating membership degree for "HIGH" label
        label_1(:,j)=[tt1;tt2;tt3]; 
        den=den+0.5;
    end
end

lbl_1=[((sum(label_1(1,:)))/den),((sum(label_1(2,:)))/den),((sum(label_1(3,:)))/den)]; % calculating total truth degree for each labels (L,M,H)
[maxNum, maxIndex] = max(lbl_1(:,:)); % finding max truth degree

sentence_21=[sentence_21;"It is",s21_labels(1,maxIndex) ,"in the MIDDAY",maxNum];


%% 22. SENTENCE

% " and towards EVENING, it reaches "LOW" level."

s22_labels = {'low','normal','high'}; % Hourly density labels which membership calculated with fuzzy c-means clustering

sentence_22=[];

stop_hourly_density=hourly_density(1,:);    
[maxNum, maxIndex] = max(stop_hourly_density(:,:)); % MaxNum shows the membership degree
[row, col] = ind2sub(size(stop_hourly_density,1), maxIndex); % row shows MaxNum's row

[membership_degree]=fuzzy_c_means(hourly_density(1,:)',3);
membership_degree=sortrows(membership_degree,col); % this sorts matrix from the first coloumn and keep the rows same

label_1=[]; % calculating Truth degre
den=0; % counting denominator of truth degree
for j=1:6 % counting hour based (15,16,17,18,19,20 for morning) 
    if ((j+14)~=15) || ((j+14)~=20) % this is for 16,17,18,19 whose memebership is 1.0
        tt1=min(1,membership_degree(1,j+9)); % calculating membership degree for "LOW" label
        tt2=min(1,membership_degree(2,j+9)); % calculating membership degree for "NORMAL" label
        tt3=min(1,membership_degree(3,j+9)); % calculating membership degree for "HIGH" label
        label_1(:,j)=[tt1;tt2;tt3];
        den=den+1;
    else % this is for 15,20 whose membership is 0.5
        tt1=min(0.5,membership_degree(1,j+9)); % calculating membership degree for "LOW" label
        tt2=min(0.5,membership_degree(2,j+9)); % calculating membership degree for "NORMAL" label
        tt3=min(0.5,membership_degree(3,j+9)); % calculating membership degree for "HIGH" label
        label_1(:,j)=[tt1;tt2;tt3]; 
        den=den+0.5;
    end
end

lbl_1=[((sum(label_1(1,:)))/den),((sum(label_1(2,:)))/den),((sum(label_1(3,:)))/den)]; % calculating total truth degree for each labels (L,M,H)
[maxNum, maxIndex] = max(lbl_1(:,:)); % finding max truth degree

sentence_22=[sentence_22;"and towards EVENING, it reaches",s22_labels(1,maxIndex),"level.",maxNum];


%% 23. SENTENCE

% "In the NIGHT, density has a "LOW" level."

s23_labels = {'low','normal','high'}; % Hourly density labels which membership calculated with fuzzy c-means clustering

sentence_23=[];

stop_hourly_density=hourly_density(1,:);    
[maxNum, maxIndex] = max(stop_hourly_density(:,:)); % MaxNum shows the membership degree
[row, col] = ind2sub(size(stop_hourly_density,1), maxIndex); % row shows MaxNum's row

[membership_degree]=fuzzy_c_means(hourly_density(1,:)',3);
membership_degree=sortrows(membership_degree,col); % this sorts matrix from the first coloumn and keep the rows same

label_1=[]; % calculating Truth degre
den=0; % counting denominator of truth degree
for j=1:4 % counting hour based (20,21,22,23 for morning) 
    if (j+19)~=20 % this is for 21,22,23 whose memebership is 1.0
        tt1=min(1,membership_degree(1,j+14)); % calculating membership degree for "LOW" label
        tt2=min(1,membership_degree(2,j+14)); % calculating membership degree for "NORMAL" label
        tt3=min(1,membership_degree(3,j+14)); % calculating membership degree for "HIGH" label
        label_1(:,j)=[tt1;tt2;tt3];
        den=den+1;
    else % this is for 20 whose membership is 0.5
        tt1=min(0.5,membership_degree(1,j+14)); % calculating membership degree for "LOW" label
        tt2=min(0.5,membership_degree(2,j+14)); % calculating membership degree for "NORMAL" label
        tt3=min(0.5,membership_degree(3,j+14)); % calculating membership degree for "HIGH" label
        label_1(:,j)=[tt1;tt2;tt3]; 
        den=den+0.5;
    end
end

lbl_1=[((sum(label_1(1,:)))/den),((sum(label_1(2,:)))/den),((sum(label_1(3,:)))/den)]; % calculating total truth degree for each labels (L,M,H)
[maxNum, maxIndex] = max(lbl_1(:,:)); % finding max truth degree

sentence_23=[sentence_23;"In the NIGHT, density is at a ",s23_labels(1,maxIndex)," level",maxNum];

%% 24. SENTENCE

% "The busiest hour of the whole stops in Kayseri is "17:00", with "1147" boardings."

sentence_24=[];

stop_hourly_density=hourly_density(1,:);    
[maxNum, maxIndex] = max(stop_hourly_density(:,:)); % MaxNum shows the membership degree

sentence_24=[sentence_24;"The busiest hour in Kayseri with",maxNum,"boarding is at",(maxIndex+5),":00 o'clock.",1];

%% 25. SENTENCE

% "Overall, the most seen passenger type is Full Card with 113 boarding."

s25_labels = {'full','discounted','free'};

data_card=[];

sentence_25=[];

for i=1:14 %aggregating all days to count each card type boarding
    temp1=table2array(data10(1,i)); 
    data_card=[data_card;temp1];

    temp2=table2array(data17(1,i));
    data_card=[data_card;temp2];

    temp3=table2array(data1737(1,i));
    data_card=[data_card;temp3];

    temp4=table2array(data2771(1,i));
    data_card=[data_card;temp4];
end

card_types=[]; % this matrix shows card type boarding

for i=1:size(s25_labels,2)
    varble=2^(3-i); % this is for finding 25, 50, 100; those are cards code in data
    card_types(1,i)=[sum(data_card(:,5)==(varble*25))];
end

card_name=[];

[maxNum, maxIndex] = max(card_types(1,:));
card_name=[card_name,s25_labels(1,maxIndex)];
sentence_25=[sentence_25;"Overall, the most seen passenger type is ",s25_labels(1,maxIndex),"card with",maxNum,"boarding.",1];

%% 26. SENTENCE

% While the density of discounted card types is at a normal level, Free type is at low level..

s26_labels = {'full','discounted','free'}; 

card_name=[];
sentence_26=[];
 
[minNum, minIndex] = min(card_types(1,:)); % looking for min value "low"
card_name=[card_name,s26_labels(1,minIndex)];

[roww, colmn] = find(card_types(1,:) == median(card_types(1,:))); % looking for "normal" value

sentence_26=[sentence_26;"While the density of ",s26_labels(1,colmn)," card types is at a normal level, ",s26_labels(1,minIndex)," type has a low level with",minNum,"boarding.",1];

%% 27. SENTENCE 

% "In terms of lines, the busiest at the stop is line E75, while line 7567 has a low level."

s27_labels = {'low','normal','high'}; % Hourly density labels which membership calculated with fuzzy c-means clustering

data_temp=[];

for i=1:14 %aggregating all days for each bus stop to detect dublicated lines and remove them
    temp1=data10(1,i);
    temp1=table2array(temp1);
    data_temp=[data_temp;temp1];   
    
    temp2=data17(1,i);
    temp2=table2array(temp2);
    data_temp=[data_temp;temp2];
    
    temp3=data1737(1,i);
    temp3=table2array(temp3);
    data_temp=[data_temp;temp3];
    
    temp4=data2771(1,i);
    temp4=table2array(temp4);
    data_temp=[data_temp;temp4];
end

data_temp=data_temp(:,4); % just selecting "line" coloumn
freq_line_overall=unique(data_temp(:,1));

data_line=[];

for i=1:14 %aggregating all days for each bus stop to detect lines.
    
    temp1=table2array(data10(1,i)); 
    data_line=[data_line;temp1];

    temp2=table2array(data17(1,i));
    data_line=[data_line;temp2];

    temp3=table2array(data1737(1,i));
    data_line=[data_line;temp3];

    temp4=table2array(data2771(1,i));
    data_line=[data_line;temp4];  
end

for i=1:size(freq_line_overall,1) % this counting line frequency in bus stop
    freq_line_overall(i,2)=sum(data_line(:,4)==freq_line_overall(i,1)); 
end


sentence_27=[];

stop_card_via_hours=freq_line_overall(:,2);    
[maxNum, maxIndex] = max(stop_card_via_hours(:,:)); % MaxNum shows the membership degree
[membership_degree]=fuzzy_c_means(freq_line_overall(:,2),3);
membership_degree=sortrows(membership_degree,maxIndex); % this sorts matrix from the first coloumn and keep the rows same
combined=[freq_line_overall';membership_degree]; % combine in the same matrix to sort
sorted_combined=sortrows(combined',2); % sorted according to freq.

high_level_line=sorted_combined(size(freq_line_overall,1),1);
low_level_line=sorted_combined(1,1);
truth=min(sorted_combined(size(freq_line_overall,1),5),sorted_combined(1,3));

sentence_27=[sentence_27;"In terms of lines, the busiest line in Kayseri is line ",high_level_line,", while line",low_level_line,"has a low density level.",truth];

%% OVERALL SENTENCES

% combining all sentences
sentencesoverall{1}=sentence_19;
sentencesoverall{2}=sentence_20;
sentencesoverall{3}=sentence_21;
sentencesoverall{4}=sentence_22;
sentencesoverall{5}=sentence_23;
sentencesoverall{6}=sentence_24;
sentencesoverall{7}=sentence_25;
sentencesoverall{8}=sentence_26;
sentencesoverall{9}=sentence_27;

TD_overall=[];

temp=[];

for j=1:9
    temp=table2array(sentencesoverall(1,j));
    allsentences_overall(j,1:(size(temp,2)-1))=cellstr(temp(1,1:(size(temp,2)-1)));
    TD_overall=[TD_overall,str2num(temp(1,size(temp,2)))];
end
truth_degree_overall=min(TD_overall);



