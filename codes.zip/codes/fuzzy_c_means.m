function [memberships]=fuzzy_c_means(X,cluster_number)
%This function makes the fuzzy c means clustering to create the membership of data_X.
% The "memberships" output shows the membership for each cluster.
q=istable(X);
if q==1
    X=table2array(X);
end

[centers,U] = fcm(X,cluster_number);
memberships=U;

end