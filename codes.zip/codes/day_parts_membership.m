function [memberships]=day_parts_membership(x)
%This function creates membership of hourly day part


if x<10
    memberships=[1;0;0;0];
elseif x<11
    memberships=[0.5;0.5;0;0];
elseif x<15
    memberships=[0;1;0;0];
elseif x<16
    memberships=[0;0.5;0.5;0];
elseif x<20
    memberships=[0;0;1;0];
elseif x<21
    memberships=[0;0;0.5;0.5];
else
    memberships=[0;0;0;1];   
end
    


end